<!DOCTYPE HTML>
<html>    
    <head>
        <title>Startsiden; <?php echo date("d.m.Y");?></title>
        <meta charset="UTF-8">
        <meta name="description" content="Startside for faget Webprogrammering i PHP">
        <meta name="keywords" content="PHP, Tutorials, Øving, Webprogrammering, NTNU">
        <meta http-equiv="refresh" content="60">
    </head>
    <body>
        <a href="Oppgave1.php">Oppgave 1</a>
        <br>
        <a href="Oppgave2.php">Oppgave 2</a>
        <br>
        <a href="Oppgave3.php">Oppgave 3 - Uten skjema</a><br>
        <a href="../Oving2/Oppgave2.php">Oppgave 3 - Med skjema(../oving2/oppgave2)</a>
    </body>
</html>