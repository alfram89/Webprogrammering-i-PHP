<?php
    echo "<h1>Informasjon om deg selv</h1>";
        echo "Du heter " . $_GET['navn'] . " og elsker å drive med " . $_GET['interesse'] . " på fritiden."; //En enkel setning med navn og interesse fra form.
?>